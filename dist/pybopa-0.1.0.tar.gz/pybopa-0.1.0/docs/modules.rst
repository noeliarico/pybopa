Documentación ``pybopa``
=========================

.. toctree::
   :maxdepth: 3

   pybopa
