El paquete para extraer información del BOPA
=============================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   readme
   installation
   modules
   usage
   history

Indices and tables
==================
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`