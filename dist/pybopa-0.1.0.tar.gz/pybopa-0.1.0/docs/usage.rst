===============
Cómo usarlo
===============

Para utilizar el paquete ``pybopa`` lo primero que debes hacer es importarlo::

    import pybopa

Con esto, ya tienes acceso a todas sus funcionalidades. Puedes acceder a la clase ``Boletin`` y a la clase ``Disposicion``.