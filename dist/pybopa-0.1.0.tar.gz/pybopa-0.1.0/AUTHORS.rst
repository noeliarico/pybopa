=======
Autores
=======

Development Lead
----------------

* Noelia Rico <noeliarico@uniovi.es>

Univesidad de Oviedo. Departamento de Informática, Área de Ciencias de la Computación e Inteligencia Artificial.

Contributors
------------

None yet. Why not be the first?
